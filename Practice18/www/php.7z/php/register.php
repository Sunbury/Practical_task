<?php
error_reporting(-1);
$myfile=fopen("../passwords.txt", 'a') or die("Unable");
$login=$_POST['usrname'];
$password=$_POST['psw'];
$wlogin=fwrite($myfile, $login.';'.$password."\n");
fclose($myfile);
header("Location: ../register.html");
exit();
?>